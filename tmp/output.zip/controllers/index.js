const PetsController = require('./PetsController');

module.exports = {
  PetsController,
};
