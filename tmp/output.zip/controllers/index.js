const PetController = require('./PetController');
const StoreController = require('./StoreController');
const UserController = require('./UserController');

module.exports = {
  PetController,
  StoreController,
  UserController,
};
