const PetsService = require('./PetsService');

module.exports = {
  PetsService,
};
