const PetService = require('./PetService');
const StoreService = require('./StoreService');
const UserService = require('./UserService');

module.exports = {
  PetService,
  StoreService,
  UserService,
};
